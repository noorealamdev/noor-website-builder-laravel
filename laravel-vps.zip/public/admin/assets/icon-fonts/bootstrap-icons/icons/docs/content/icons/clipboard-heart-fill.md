---
title: Clipboard heart fill
categories:
  - Real world
tags:
  - copy
  - paste
---
