---
title: Clipboard x fill
categories:
  - Real world
tags:
  - copy
  - paste
---
