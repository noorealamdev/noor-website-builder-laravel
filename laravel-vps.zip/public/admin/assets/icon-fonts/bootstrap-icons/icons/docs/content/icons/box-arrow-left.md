---
title: Box arrow left
categories:
  - Box arrows
tags:
  - arrow
  - logout
  - signout
  - exit
---
