---
title: Clipboard
categories:
  - Real world
tags:
  - copy
  - paste
---
